package hk.edu.polyu.comp.comp2021.jungle.model;

public class JungleGame {

    public JungleGame(){}

}
