package hk.edu.polyu.comp.comp2021.jungle;

import hk.edu.polyu.comp.comp2021.jungle.model.JungleGame;

public class Application {

    public static void main(String[] args){
        JungleGame game = new JungleGame();

        // start playing the game
    }
}
