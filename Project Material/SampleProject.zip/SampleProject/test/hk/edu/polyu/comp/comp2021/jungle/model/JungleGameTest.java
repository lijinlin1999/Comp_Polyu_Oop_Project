package hk.edu.polyu.comp.comp2021.jungle.model;

import hk.edu.polyu.comp.comp2021.jungle.model.JungleGame;
import org.junit.Test;


public class JungleGameTest {
    @org.junit.Before
    public void setUp() throws Exception {

    }

    @Test
    public void testJungleGameConstructor(){
        JungleGame game = new JungleGame();
        assert true;
    }

}